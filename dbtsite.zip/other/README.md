# Diyagala Boystown Website

This is the static website for Diyagala Boystown, built using simple HTML, CSS, and JavaScript.

## Setup & Hosting on GitHub Pages

1. **Initialize Git & Push**:
   Initialize a git repository in this folder, commit all the files, and push them to a new GitHub repository.
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin <your-repo-url>
   git push -u origin main
   ```

2. **Enable GitHub Pages**:
   - Go to your repository on GitHub.
   - Click on **Settings** -> **Pages** (under the "Code and automation" section on the left).
   - Under **Source**, select the `main` branch and `/ (root)` folder, then click **Save**.
   - Your site will be published at `https://<username>.github.io/<repo-name>/`.

3. **Setting Up Custom Domain**:
   - Open the `CNAME` file in this folder and replace `your-custom-domain.com` with your actual domain name (e.g., `diyagalaboystown.org`). Commit and push this change.
   - In your domain registrar's DNS settings (e.g., GoDaddy, Namecheap):
     - Add an **A Record** pointing to GitHub's IP addresses:
       - `185.199.108.153`
       - `185.199.109.153`
       - `185.199.110.153`
       - `185.199.111.153`
     - Add a **CNAME Record** with the host `www` pointing to your GitHub pages URL (`<username>.github.io`).
   - Go back to GitHub **Settings** -> **Pages**, and under **Custom domain**, type your domain and click **Save**. Check "Enforce HTTPS".

## How to Update Content (For the Admin Team)

The website uses a "Headless CMS" architecture via Blogger. This allows the non-technical administration team to post news, events, and photos easily from their phones or computers without touching any code.

### Connecting Blogger as a Headless CMS

1. **Create a Free Blog:** The admin team creates a free blog on Blogger (e.g., `diyagalaboystown.blogspot.com`).
2. **Make it Public:** Ensure the blog's privacy settings are set to public so the website can read the feed.
3. **Configure the URL:**
   - Open `script.js` in this folder.
   - Look for the `BLOGGER_URL` variable at the top of the file (Line 3).
   - Paste the blog's JSON feed URL into the quotes. It should look exactly like this:
     ```javascript
     const BLOGGER_URL = 'https://<your-blog-name>.blogspot.com/feeds/posts/default?alt=json';
     ```
4. **Publish Updates:** That's it! Whenever the admin team writes and publishes a post on Blogger, our custom JavaScript automatically fetches it, ensures the content is secure, and renders it beautifully within the website's dark theme.
